const BRIDGE = "http://127.0.0.1:38746";
const BRIDGE_TOKEN = "932299abedd4c30b80d838569e083ace0a9e67fb0924136caeb281e1b48b8f6a";
const volumes = new Map();
const favicons = new Map();

async function browserName() {
  const ua = navigator.userAgent;
  if (ua.includes("Edg/")) return "edge";
  if (ua.includes("OPR/")) return "opera";
  if (ua.includes("Vivaldi/")) return "vivaldi";
  try {
    if (navigator.brave && await navigator.brave.isBrave()) return "brave";
  } catch (_) {}
  return "chrome";
}

async function faviconData(url) {
  if (!url) return "";
  if (url.startsWith("data:image/")) return url;
  if (favicons.has(url)) return favicons.get(url);
  try {
    const response = await fetch(url);
    if (!response.ok) return "";
    const blob = await response.blob();
    if (blob.size > 180000) return "";
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 0x8000) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    }
    const data = `data:${blob.type || "image/png"};base64,${btoa(binary)}`;
    favicons.set(url, data);
    return data;
  } catch (_) {
    return "";
  }
}

function queryTabs() {
  return new Promise((resolve) => chrome.tabs.query({}, resolve));
}

async function publishTabs() {
  try {
    const browserId = await browserName();
    const tabs = await queryTabs();
    const items = await Promise.all(tabs.map(async (tab) => ({
      id: tab.id,
      title: tab.title || tab.url || "Aba sem título",
      url: tab.url || "",
      favicon: tab.audible ? await faviconData(tab.favIconUrl) : "",
      audible: Boolean(tab.audible),
      muted: Boolean(tab.mutedInfo && tab.mutedInfo.muted),
      volume: volumes.get(tab.id) ?? 1,
    })));
    await fetch(`${BRIDGE}/tabs?browser=${browserId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Soundeck-Token": BRIDGE_TOKEN },
      body: JSON.stringify({ browser: browserId, tabs: items }),
    });
  } catch (_) {
    // The desktop app may be closed; reconnect on the next event or alarm.
  }
}

function sendTabMessage(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, () => {
      void chrome.runtime.lastError;
      resolve();
    });
  });
}

async function sendCommands() {
  try {
    const browserId = await browserName();
    const response = await fetch(`${BRIDGE}/commands?browser=${browserId}`, {
      headers: { "X-Soundeck-Token": BRIDGE_TOKEN },
    });
    if (!response.ok) return;
    const commands = await response.json();
    for (const command of commands) {
      if (command.action === "volume") {
        volumes.set(command.id, command.value);
        chrome.storage.local.set({ [`volume-${command.id}`]: command.value });
      } else if (command.action === "mute") {
        const [tab] = await new Promise((resolve) => chrome.tabs.get(command.id, (t) => resolve([t || null])));
        if (tab) {
          await new Promise((resolve) => chrome.tabs.update(command.id, {
            muted: !Boolean(tab.mutedInfo && tab.mutedInfo.muted),
          }, resolve));
        }
      }
      await sendTabMessage(command.id, command);
    }
  } catch (_) {
    // Retry on the next alarm.
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.kind === "ready" && sender.tab) {
    const key = `volume-${sender.tab.id}`;
    chrome.storage.local.get(key, (stored) => {
      const volume = stored[key] ?? 1;
      volumes.set(sender.tab.id, volume);
      sendResponse({ action: "volume", value: volume });
    });
    return true;
  }
  return false;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  volumes.delete(tabId);
  chrome.storage.local.remove(`volume-${tabId}`);
  publishTabs();
});
chrome.tabs.onUpdated.addListener(() => publishTabs());
chrome.tabs.onActivated.addListener(() => publishTabs());
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "volume-deck-refresh") {
    publishTabs();
    sendCommands();
  }
});
chrome.alarms.create("volume-deck-refresh", { periodInMinutes: 0.5 });
publishTabs();
sendCommands();
