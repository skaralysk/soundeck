let currentVolume = 1;

function setVolume(value) {
  currentVolume = Math.max(0, Math.min(1, Number(value)));
  applyToPage();
}

function applyVolume(node) {
  if (!(node instanceof HTMLMediaElement)) return;
  // Não force volume em todo `volumechange`: isso disputa com os controles do
  // próprio site e pode fazer o ajuste do Soundeck parecer inoperante.
  if (Math.abs(node.volume - currentVolume) > 0.005) node.volume = currentVolume;
}

function applyToPage(root = document) {
  applyVolume(root);
  root.querySelectorAll?.("audio, video").forEach(applyVolume);
  root.querySelectorAll?.("*").forEach((element) => {
    if (element.shadowRoot) applyToPage(element.shadowRoot);
  });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.action === "volume") {
    setVolume(message.value);
    sendResponse({ ok: true, volume: currentVolume });
  }
});

chrome.runtime.sendMessage({ kind: "ready" }, (response) => {
  void chrome.runtime.lastError;
  if (response && response.action === "volume") {
    currentVolume = Math.max(0, Math.min(1, Number(response.value)));
    applyToPage();
  }
});

new MutationObserver((records) => {
  for (const record of records) {
    for (const node of record.addedNodes) {
      applyVolume(node);
      applyToPage(node);
    }
  }
}).observe(document, { childList: true, subtree: true });
